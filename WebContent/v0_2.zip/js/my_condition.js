$(document).ready(function(){
	var show_info = true;
	if(show_info) {
		$(".my_info").show();
		$(".my_condition").hide();
	} else {
		$(".my_info").hide();
		$(".my_condition").show();
	}

})