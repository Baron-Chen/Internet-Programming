$(document).ready(function(){
	$("#home").on("click", function(){
		window.location	= 'index.html'
	})
	$("#reservation").on("click", function(){
		window.location	= 'reservation.html'
	})
	$(".reserve").on("click", function(){
		window.location	= 'reservation.html'
	})
	$("#menu").on("click", function(){
		window.location	= 'menu.html'
	})
	$("#mine").on("click", function(){
		window.location	= 'mine.html'
	})

	$("#online").on("click", function(){
		window.location	= 'menu.html'
	})

})